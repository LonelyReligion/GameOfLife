/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.lab1.agnieszka.tazbirek.controller;
import pl.polsl.lab1.agnieszka.tazbirek.model.Cell;

/**
 * Controller class for the Cell class from models. 
 * @author Agnieszka Tażbirek
 * @version 1.0
 */
public class CellController {
    
}
