/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */

/**
 * Contains two controller classes: {@link pl.polsl.lab1.agnieszka.tazbirek.controller.CellController} and {@link pl.polsl.lab1.agnieszka.tazbirek.controller.GridController}.
 */
package pl.polsl.lab1.agnieszka.tazbirek.controller;
