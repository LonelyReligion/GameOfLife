/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package pl.polsl.lab1.agnieszka.tazbirek.model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *  Test class for methods in Cell class
 * @author Agnieszka Tażbirek
 * @version 1.0
 */
public class CellTest {
    private Cell cell;
    
    public CellTest() {
    }
    
    @BeforeEach
    public void setUp() {
        cell = new Cell();
    }
     
    //no tests
}
