/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */

/**
 * Contains one Exception class: {@link pl.polsl.lab1.agnieszka.tazbirek.exception.InvalidDimensionsException}.
 */
package pl.polsl.lab1.agnieszka.tazbirek.exception;
