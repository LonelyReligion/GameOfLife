/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */

/**
 * Contains JakartaRestConfiguration java file.
 */
package pl.polsl.lab4.agnieszka.tazbirek.gameoflifewebversion;
