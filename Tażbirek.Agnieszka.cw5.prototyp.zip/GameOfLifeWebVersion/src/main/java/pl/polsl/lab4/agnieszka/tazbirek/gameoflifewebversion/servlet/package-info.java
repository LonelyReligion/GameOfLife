/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */

/**
 * Package contains two servlets {@link pl.polsl.lab4.agnieszka.tazbirek.gameoflifewebversion.servlet.GridInfoServlet} and {@link pl.polsl.lab4.agnieszka.tazbirek.gameoflifewebversion.servlet.GridSetupServlet}
 */
package pl.polsl.lab4.agnieszka.tazbirek.gameoflifewebversion.servlet;