/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */
/**
 * Package with three model classes: {@link pl.polsl.lab4.agnieszka.tazbirek.gameoflifewebversion.model.Cell}, {@link pl.polsl.lab4.agnieszka.tazbirek.gameoflifewebversion.model.Grid} and {@link pl.polsl.lab4.agnieszka.tazbirek.gameoflifewebversion.model.Session}.
 */
package pl.polsl.lab4.agnieszka.tazbirek.gameoflifewebversion.model;
